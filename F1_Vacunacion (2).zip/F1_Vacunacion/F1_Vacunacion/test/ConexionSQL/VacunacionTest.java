/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author feibe
 */
public class VacunacionTest {
    
    public VacunacionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    /**
     * Test of agregarUsuarioBaseDeDatos method, of class Vacunacion.
     * @throws java.sql.SQLException
     * @throws java.lang.Exception
     */
    @Test
    public void testAgregarUsuarioBaseDeDatos() throws SQLException, Exception {
        System.out.println("agregarUsuarioBaseDeDatos");
        String pId_Usu = "";
        String pTipo = "";
        String pFechaexp = "";
        String pNombres = "";
        String pApellidos = "";
        String pFechanaci = "";
        String pGenero = "";
        String pTelefono = "";
        String pCorreo = "";
        String pDepartamento = "";
        String pCiudad = "";
        String pDireccion = "";
        Vacunacion instance = new Vacunacion();
        instance.agregarUsuarioBaseDeDatos("00", "Identidad", "232323", "juana", "maruqez", "234234", "femenino", "231231", "@@@", "Nariño", "Pasto", "####");
        
    }

    /**
     * Test of modificarUsuarioBaseDeDatos method, of class Vacunacion.
     * @throws java.lang.Exception
     */
    @Test
    public void testModificarUsuarioBaseDeDatos() throws Exception {
        System.out.println("modificarUsuarioBaseDeDatos");
        String pId_Usu = "";
        String pTipo = "";
        String pFechaexp = "";
        String pNombres = "";
        String pApellidos = "";
        String pFechanaci = "";
        String pGenero = "";
        String pTelefono = "";
        String pCorreo = "";
        String pDepartamento = "";
        String pCiudad = "";
        String pDireccion = "";
        Vacunacion instance = new Vacunacion();
        instance.modificarUsuarioBaseDeDatos("14", "Cedula", "232323", "juliana", "maruqez", "234234", "Masculino", "320320", "@@@", "Nariño", "Pasto", "####");
        
    }


    /**
     * Test of eliminarUsuario method, of class Vacunacion.
     * @throws java.lang.Exception
     */
    @Test
    public void testEliminarUsuario() throws Exception {
        System.out.println("eliminarUsuario");
        String pId_Usu = "";
        DefaultTableModel pModel = null;
        Vacunacion instance = new Vacunacion();
        instance.eliminarUsuario("12", pModel);
        
    }
    
}
