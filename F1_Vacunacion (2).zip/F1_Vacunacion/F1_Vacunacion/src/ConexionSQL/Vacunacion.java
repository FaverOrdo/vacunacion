/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQL;


import Mundo.Cita;
import Mundo.EPS;
import Mundo.Usuario;
import com.mysql.cj.x.protobuf.MysqlxConnection;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author feibe
 */
public final class Vacunacion {

    
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    private EPS epsPrimero;
    private EPS epsUltimo;
    
    private Cita citaPrimero;
    private Cita citaUltima;
    
    private Usuario clienteRaiz;
    private Cita clientE2;
    
    // -----------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------
    /**
     * Direccion IP del servidor de base de datos
     */
    private final static String DIRECCION = "localhost";

    /**
     * Puerto de conexion a la base de datos
     */
    private final static String PUERTO = "3306";

    /**
     * Nombre de la base de datos
     */
    private final static String NOMBRE = "vacuna";

    /**
     * URL de conexion para la .
     */
    private final static String URL = "jdbc:mysql://"+ DIRECCION +":"+ PUERTO +"/"+ NOMBRE+"?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";

    /**
     * Usuario de base de datos
     */
    private final static String USER = "root";
    /**
     * Contraseña de base de datos
     */
    private final static String PASS = "";
    
     //---------------------------------------------Attributes---------------------------------------------

    /**
     * Variable de conexion a la base de datos
     */
    public Connection conexion;
    
    

    //---------------------------------------------Constructor---------------------------------------------

    /**
     * Se encarga de inicilizar la variable de conexion y conectar a la base de datos
     * @param pModel
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws Exception
     */
    public Vacunacion( final DefaultTableModel pModel ) throws ClassNotFoundException, SQLException, Exception
    {
        conexion = DriverManager.getConnection(URL, USER, PASS);
        if( conexion == null )
            throw new Exception("No se pudo encontrar la base de datos");
        cargarDatos( pModel);
        
    }
/**
 * 
 * @throws ClassNotFoundException
 * @throws SQLException
 * @throws Exception
 */
    public Vacunacion() throws ClassNotFoundException, SQLException, Exception
    {
        conexion = DriverManager.getConnection(URL, USER, PASS);
        if( conexion == null )
            throw new Exception("No se pudo encontrar la base de datos");
    }

    /**
     * Prepara una sentencia SQL para actualizar la informacion de la base de datos
     * @param pSQL Sentencia SQL
     * @return La sentencia lista para ser consumida
     * @throws SQLException
     */
    public PreparedStatement darSentenciaSQLPreparada(final String pSQL ) throws SQLException
    {
        return conexion.prepareStatement( pSQL );
    }

    /**
     * Hace una consulta en la base de datos dado una sentencia SQL
     * @param pSQL sentencia para ser consultada en la base de datos
     * @return El resultado de la consulta
     * @throws SQLException
     */
    public ResultSet darResultadoDeSentencia(final String pSQL ) throws SQLException
    {
        return conexion.createStatement().executeQuery( pSQL );
    }
    
    
     /**
     * Este metodo se encarga de cargar toda la informacion de la base de datos en
     * en el modelo del mundo, ademas de cargarla en la interfaz en la lista.
     * @param pModel Lista de la interfaz que sera rellenada con la informacion de
     * los usuarios.
     * @throws Exception
     */
    public void cargarDatos( final DefaultTableModel pModel ) throws Exception
    {
        try (ResultSet resultadosUsuario = darResultadoDeSentencia( "SELECT * FROM usuario;" )) {
            while ( resultadosUsuario.next() )
            {
                agregarUsuario(resultadosUsuario.getString(1), resultadosUsuario.getString(2), resultadosUsuario.getString(3), resultadosUsuario.getString(4),
                        resultadosUsuario.getString(5), resultadosUsuario.getString(6), resultadosUsuario.getString(7), resultadosUsuario.getString(8), resultadosUsuario.getString(9),
                        resultadosUsuario.getString(10), resultadosUsuario.getString(11), resultadosUsuario.getString(12) );
                pModel.addColumn(resultadosUsuario.getString(3)+"-"+resultadosUsuario.getString( 2 )+"-"+resultadosUsuario.getString( 1 ) );
            }
        }
    }

    
    /**
     * Agrega un usuario a la base de datos, al modelo del mundo.
     * @param pId_Usu
     * @param pTipo
     * @param pFechaexp
     * @param pNombres
     * @param pApellidos
     * @param pFechanaci
     * @param pGenero
     * @param pTelefono
     * @param pCorreo
     * @param pDireccion
     * @param pDepartamento
     * @param pCiudad
     * @throws Exception 
     */
    public void agregarUsuarioBaseDeDatos(final String pId_Usu,final String pTipo, final String pFechaexp, final String pNombres, final String pApellidos, final String pFechanaci, final String pGenero,
                final String pTelefono, final String pCorreo, final String pDepartamento, final String pCiudad, final String pDireccion ) 
    {
        final PreparedStatement preparedStatement;
        try {
            preparedStatement = darSentenciaSQLPreparada( "INSERT INTO usuario VALUES ( ?,?,?,?,?,?,?,?,?,?,?,? );" );
        preparedStatement.setString( 1, pId_Usu );
        preparedStatement.setString( 2, pTipo );
        preparedStatement.setString( 3, pFechaexp);
        preparedStatement.setString(4,pNombres);
        preparedStatement.setString(5,pApellidos);
        preparedStatement.setString( 6, pFechanaci);
        preparedStatement.setString(7,pGenero);
        preparedStatement.setString(8,pTelefono);
        preparedStatement.setString(9,pCorreo);
        preparedStatement.setString(10,pDepartamento);
        preparedStatement.setString(11,pCiudad);
        preparedStatement.setString(12,pDireccion);
        agregarUsuario( pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion );
        
        preparedStatement.execute();
        preparedStatement.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            Logger.getLogger(Vacunacion.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    

    /**
     * Modifica un usuario a la base de datos, al modelo del mundo.
     * @param pId_Usu
     * @param pTipo
     * @param pFechaexp
     * @param pNombres
     * @param pApellidos
     * @param pFechanaci
     * @param pGenero
     * @param pTelefono
     * @param pCorreo
     * @param pDepartamento
     * @param pCiudad
     * @param pDireccion
     * @throws SQLException
     * @throws Exception 
     */
    public void modificarUsuarioBaseDeDatos(final String pId_Usu,final String pTipo, final String pFechaexp, final String pNombres, final String pApellidos, final String pFechanaci, final String pGenero,
        final String pTelefono, final String pCorreo, final String pDepartamento, final String pCiudad, final String pDireccion) throws SQLException, Exception {
        try (
                PreparedStatement preparedStatement = darSentenciaSQLPreparada( "UPDATE usuario SET tipo='"+pTipo
                        +"',fechaexp='"+pFechaexp
                        +"',nombres='"+pNombres
                        +"',apellidos='"+pApellidos
                        +"',fechanaci='"+pFechanaci
                        +"',genero='"+pGenero
                        +"',telefono='"+pTelefono
                        +"',correo='"+pCorreo 
                        +"',departamento='"+pDepartamento
                        +"',ciudad='"+pCiudad
                        +"',direccion='"+pDireccion
                        +"' WHERE id_Usu='"+pId_Usu+"'")) {
            preparedStatement.executeUpdate();
            preparedStatement.close();
        }catch (Exception e){
            
        }
        
    }
    /**
     *  Agrega una EPS al modelo del mundo.
     * @param pId_Eps
     * @param pNombre_EPS
     * @throws Exception 
     */
    private void agregarEPS( final String pId_Eps, final String pNombre_EPS ) throws Exception
    {
        if (epsPrimero != null)
            epsUltimo = epsUltimo.agregarEPS(pId_Eps, pNombre_EPS);
        else
        {
            epsPrimero = new EPS(pId_Eps, pNombre_EPS);
            epsUltimo = epsPrimero;
        }
    }
    
    /**
     * Metodo encargado de Agregar un usuario
     * @param pId_Usu
     * @param pTipo
     * @param pFechaexp
     * @param pNombres
     * @param pApellidos
     * @param pFechanaci
     * @param pGenero
     * @param pTelefono
     * @param pCorreo
     * @param pDepartamento
     * @param pCiudad
     *@param pDireccion
     * @throws Exception 
     */
    private void agregarUsuario( final String pId_Usu,final String pTipo, final String pFechaexp, final String pNombres, final String pApellidos, final String pFechanaci, final String pGenero,
                final String pTelefono, final String pCorreo, final String pDepartamento, final String pCiudad, final String pDireccion ) throws Exception
    {
        if (clienteRaiz != null)
            clienteRaiz.agregarUsuario(pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion);
        else
            clienteRaiz = new Usuario(pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci, pGenero, pTelefono, pCorreo, pDepartamento, pCiudad, pDireccion);
    }

    

    public void cargar(JTable tblaUsuario, String cad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    } 
    
     public void eliminarUsuario( final String pId_Usu, final DefaultTableModel pModel ) throws SQLException, Exception
    {
       final PreparedStatement preparedStatement = darSentenciaSQLPreparada
        (
                "DELETE FROM usuario WHERE id_Usu="+pId_Usu+";"
        );
       preparedStatement.executeUpdate();
       preparedStatement.close();
    }
     
     public DefaultComboBoxModel obt_Usu() throws SQLException{
         DefaultComboBoxModel ListaModelo = new DefaultComboBoxModel();
         ListaModelo.addElement("seleccione un Usuario");
         ResultSet res = this.darResultadoDeSentencia("SELECT * FROM usuario ORDER BY id_Usu ");
         try {
            while(res.next()){
                ListaModelo.addElement(res.getString("id_Usu"));
                
            }
            res.close();
         } catch (SQLException ex) {
             System.err.println(ex.getMessage());
         }
         return ListaModelo;
     }


     public void agendarCita(){
        
     }
  	
    
}