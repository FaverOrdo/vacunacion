/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

/**
 *
 * @author feibe
 */
public class Cita {
     // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

	private String num_Cita;
        private String eps;
	private String usuario;
        private String horario;
	private String fechaprimera;
	private String fechasegunda;
        
        private Cita izquierda;
        private Cita derecha;
        
        
    public Cita( final String pNum_Cita,final String pEps, final String pUsuario, final String pHorario,final String pFechaprimera, final String pFechasegunda )
    {
        num_Cita = pNum_Cita;
        eps = pEps;
        usuario = pUsuario;
        horario = pHorario;
        fechaprimera = pFechaprimera;
        fechasegunda = pFechasegunda;
    }

    public String darNum_Cita(){
            return num_Cita;
        }
        public String darEps(){
            return eps;
        }
        public String darUsuario(){
            return usuario;
        }
        public String darHorario(){
            return horario;
        }
        public String darFechaprimera(){
            return fechaprimera;
        }
        public String darFechasegunda(){
            return fechasegunda;
        }
    

    public void inOrder()
    {
        if ( izquierda != null )
        {
            izquierda.inOrder();
        }
        System.out.println( this );
        if ( derecha != null )
        {
            derecha.inOrder();
        }
    }
}
