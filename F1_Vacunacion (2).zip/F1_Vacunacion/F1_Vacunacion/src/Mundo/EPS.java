/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

/**
 *
 * @author feibe
 */
public class EPS {
    
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    private String id_EPS;
    private String nombre_EPS;
    
    private EPS anterior;
    private EPS siguiente;
    
    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------
    public EPS (final String pId_Eps, final String pNombre_EPS){
        id_EPS = pId_Eps;
        nombre_EPS = pNombre_EPS;
    }
    
    // -----------------------------------------------------------------
    // Metodos
    // -----------------------------------------------------------------
    public EPS darAnterior(){
        return anterior;
    }
    public EPS darSiguiente(){
        return siguiente;
    }
    
        public void cambiarAnterior( final EPS pEPS )
    {
        anterior = pEPS;
    }

    public EPS agregarEPS( final String pId_EPS, final String pNombre_EPS )
    {
        siguiente = new EPS( pId_EPS, pNombre_EPS );
        siguiente.cambiarAnterior( this );
        return siguiente;
    }

    @Override
    public String toString()
    {
        return "EPS{" +
                "id=" + id_EPS +
                ", nombre='" + nombre_EPS + '\'' +
                '}';
    }

    public void inOrder()
    {
        System.out.println( this );
        if ( siguiente != null )
            siguiente.inOrder();
    }


}
