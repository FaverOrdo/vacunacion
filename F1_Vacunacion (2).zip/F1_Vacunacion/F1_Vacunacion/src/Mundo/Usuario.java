/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import ConexionSQL.Vacunacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author feibe
 */
public class Usuario {
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

	private String id_Usu;
	private String tipo;
	private String fechaexp;
	private String nombres;
	private String apellidos;
	private String fechanaci;
	private String genero;
	private String telefono;
	private String correo;
        private String departamento;
	private String ciudad;
        private String direccion;
        Vacunacion vacunacion;
        
	private Usuario izquierda;
	private Usuario derecha;
	
    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

	public Usuario ( final String pId_Usu,final String pTipo, final String pFechaexp, final String pNombres, final String pApellidos, final String pFechanaci, final String pGenero,
                final String pTelefono, final String pCorreo, final String pDepartamento, final String pCiudad, final String pDireccion) {
		id_Usu = pId_Usu;
                tipo = pTipo;
                fechaexp = pFechaexp;
                nombres=pNombres;
                apellidos=pApellidos;
                fechanaci=pFechanaci;       
		genero=pGenero;
                telefono=pTelefono;
                correo=pCorreo;
                departamento=pDepartamento;
                ciudad=pCiudad;
                direccion=pDireccion;
	}

   




	
    // ----------------------------------------------------------------
    // Métodos
    // ----------------------------------------------------------------
	
	/**
	 * retorna el numero del dicumento, el nombre y la fecha de expedicion
	 * @return documento, nombre y fecha de expedicion
	 */
	
        public String darId_Usu(){
            return id_Usu;
        }
        public String darTipo(){
            return tipo;
        }
        public String darFechaexp(){
            return fechaexp;
        }
        public String darNombres(){
            return nombres;
        }
        public String darApellidos(){
            return apellidos;
        }
        public String darFechanaci(){
            return fechanaci;
        }
        public String darGenero(){
            return genero;
        }
        public String darTelefono(){
            return telefono;
        } 
        public String darCorreo(){
            return correo;
        }
       
        public String darDepartamento(){
            return departamento;
        }
        public String darCiudad(){
            return ciudad;
        }
         public String darDireccion(){
            return direccion;
        }
        
    public Usuario agregarUsuario( final String pId_Usu,final String pTipo, final String pFechaexp, final String pNombres, final String pApellidos, final String pFechanaci, final String pGenero,
                final String pTelefono, final String pCorreo, final String pDepartamento, final String pCiudad, final String pDireccion ) throws Exception
    {
        final int comparacion = String.valueOf( id_Usu ).compareToIgnoreCase( String.valueOf( pId_Usu ) );
        if ( comparacion == 0 )
            throw new Exception( "El Cliente ya se encuentra registrado!" );
        if ( comparacion > 0 )
            return izquierda == null ? izquierda = new Usuario( pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion ) 
                    : izquierda.agregarUsuario( pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion);
        else
            return (derecha == null) ? derecha = new Usuario(pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion ) 
                    : derecha.agregarUsuario( pId_Usu, pTipo, pFechaexp, pNombres, pApellidos, pFechanaci,pGenero,pTelefono,pCorreo,pDepartamento,pCiudad,pDireccion );
    }

    public Usuario buscarUsuario( final String pId_Usu )
    {
        final int comparacion = String.valueOf( pId_Usu ).compareToIgnoreCase( String.valueOf( pId_Usu ) );
        if ( comparacion == 0 )
            return this;
        else if ( comparacion > 0 )
            return izquierda == null ? null : izquierda.buscarUsuario( pId_Usu );
        else
            return (derecha == null) ? null : derecha.buscarUsuario( pId_Usu );
    }
    @Override
    public String toString()
    {
        return "usuario{" +
                "identificacion=" + id_Usu +
                "Nombres=" + nombres +
                ", Apellidos='" + apellidos + '\'' +
                '}';
    }

    public void inOrder()
    {
        if ( izquierda != null )
        {
            izquierda.inOrder();
        }
        System.out.println( this );
        if ( derecha != null )
        {
            derecha.inOrder();
        }
    }

    private PreparedStatement darSentenciaSQLPreparada(String SQL) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int updateDatos(String id_Usu, int i, String tipo, String fechaexp, String nombres, String apellidos, String fechanaci, String genero, String telefono, String correo, String direccion, String departamento, String ciudad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void modificarUsuarioBaseDeDatos(JTextField txtNumdoc3, JTextField txtTipodoc, JTextField txtFechaExp, JTextField txtNombres, JTextField txtApellidos, JTextField txtFechaNaci, JTextField txtGenero, JTextField txtTelefono, JTextField txtCorreo, JTextField txtDireccion, JComboBox<String> cbDepartamento, JComboBox<String> cbCiudad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void cargar(JTable tblaUsuario, String cad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
